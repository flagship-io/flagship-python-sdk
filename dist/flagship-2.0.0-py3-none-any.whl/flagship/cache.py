

class CacheManager:

    def __init__(self):
        super().__init__()

    def get(self, visitor_id, context={}):
        return

    def save(self, visitor_id, context={}):
        return
